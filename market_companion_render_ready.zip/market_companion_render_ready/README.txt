MARKET COMPANION LIVE — RENDER DEPLOYMENT

Files: index.html, server.py, render.yaml

Deploy:
1. Upload all three files to your GitHub repository root.
2. On Render, choose New + > Blueprint and connect this repository.
3. Render reads render.yaml. Enter OTCHARTS_API_KEY as a secret environment variable when prompted.
4. Deploy. Open the public HTTPS URL Render provides.

The app requires a valid OTCharts API key. Live streaming may require a paid provider plan. This is an independent read-only data feed, not an official Pocket Option API. Next-candle estimate is not a guaranteed prediction.
